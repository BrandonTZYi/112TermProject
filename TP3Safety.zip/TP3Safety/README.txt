A short description:
My Term Project is a rendition of the game "Into the Gungeon". In the game, you explore various dungeons, each with new enemies, and as you clear the dungeons of the enemies, you travel deeper into the dungeon. The player is equipped with a gun, that shoots the enemies and can dig through the dungeon. The enemies walk towards the player slowly, and as you get deeper into the dungeon, the number of enemies increases. How far into the dungeon can you go? 


How to run the project:
The code is all in one file, so just run the "TP3Safety" file, and play the game.


Which libraries you're using that need to be installed:
No libraries are needed to be installed, as long as the CMU 112 graphics file is loaded, nothing else will be necessary.


A list of any shortcut commands that exist:
There are no shortcuts, the game should be simple enough to demonstrate all the features just by playing it.